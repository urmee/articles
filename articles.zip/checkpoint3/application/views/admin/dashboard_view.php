<?php 

$this->load->view('admin/admin_header');
?>


<div class="container">
<div class="row">
<div class="col-lg-6 col-lg-offset-6">
<?=anchor('admin/store_article','Add Article',['class'=>'btn btn-lg btn-primary pull-right'])?>

</div>
</div>	

<?php if ($feedback=$this->session->flashdata('feedback')):?>
    <div class="row">
    <div class="col-lg-6">
<div class="alert alert-dismissible alert-info">
<?= $feedback ?>

</div>
	</div>
</div>
<?php endif;?>


	<table class="table">
	<thead>
		<th>S.No</th>
		<th>Title</th>
		<th>Action</th>
	</thead>
	
<!--for array-->
<?php if(count ($articles)):?>
	<?php foreach($articles as $article):?>
	
	<tbody>
		<tr>
			<td>1</td>
			<td><?php echo $article->title ?></td>
			<td>
			<div class="row">
			<div class="col-lg-2">
				<?= anchor("admin/edit_article/{article=>id}",'Edit',['class'=>'btn btn-default']);?>
				<!--<a href="" class="btn btn-default">Edit</a>
				-->
			</div>
			<div class="col-lg-2">
				<!--<a href="" class="btn btn-danger">Delete</a>
			--><?=
			form_open('admin/delete_article'),
			form_hidden('article_id', $article->id),
			form_submit(['name'=>'submit','value'=>'Delete','class'=>'btn btn-danger']),
			form_close();
			?>
			</div>
			</div>
			

			</td>
		</tr>
<?php endforeach;?>
	
	<?php else:?>
		<tr>
			<td colspan='3'>
			No Records Found.
				
			</td>
		</tr>
	<?php endif;?>

		</tbody>
	</table>
		
	</div>

<?php 

$this->load->view('admin/admin_footer');
?>