<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.js"></script>
<!--used of js ajust the web page while resizing-->
<script src="<?php echo base_url()?>assets/js/bootstrap.min.js"> </script>
 
  </body>
  </html>