<?php
class MY_Controller extends CI_Controller{

	public function __constructor()
	{
		//automatic implement in all controller
		if(!$this->isAuthorized()) return redirect('home'); 
	}

}

?>