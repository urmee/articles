
<?php

class Login extends MY_Controller{

	public function index()
	{
		if($this->session->userdata('user_id'))
			return redirect('admin/dashboard');
		$this->load->helper('form');
		$this->load->view('login_view');
	}

	public function admin_login(){

		//1.select-verifyor validation
		//2.match-login
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username','User Name','required|alpha|trim|max_length[20]');
		$this->form_validation->set_rules('password','Password','required');


		$this->form_validation->set_error_delimiters("<p class='text-danger'>","</p>");
				if($this->form_validation->run('admin_login')){
			//if validation pass or success

				$username=$this->input->post('username');
				$password=$this->input->post('password');
				//echo"username:$username and password:$password";
			//echo"validation Suceesful!!";
				//validation with database
				$this->load->model('Login_model');
				$login_id=$this->Login_model->login_valid($username,$password);				
					if($login_id){
					//valid user login hunxa
					//echo "password match";
					//session autoload make function to check for database userid
					$this->session->set_userdata('user_id',$login_id);
					//after login it redirect to  controller function n from there it will load dashboard view
					return redirect('Admin/dashboard');
				}
				else{
					//authentication failed
					//invald username vayo used flashdata
					$this->session->set_flashdata('Login_failed','Invalid Username/Password');
					return redirect('login');
					echo "password donot match";
				}

		}
		else {//failed
			$this->load->view('login_view');
			//echo"validation failed";
			//echo validation_errors();
		}
		
	}
	

	public function logout()
	{
		$this->session->unset_userdata('user_id');
		//$this->session->sess_destroy();
        redirect(base_url()."Login");

		//return redirect ('login');
    }

     
}
?>