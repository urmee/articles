<?php

class User extends MY_Controller{

	public function index()
	{
		//$this->load->helper('html');
		$this->load->view('user/articleslist_view');
	}
	
}
?>