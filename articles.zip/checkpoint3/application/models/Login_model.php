<?php

class Login_model extends CI_model{

	public function login_valid($username,$password){


	//checking input username validate or not with database 
//1.have to load database by using auto library
		//2.accessing autoload databse and fetching the data from database
//3.active records through

		
		$q=$this->db->where(['username'=>$username,'password'=>$password])
		->get('user');
		//select * from user(abouve query)
		if($q->num_rows()){

			//1return TRUE;
			//2$row=$q=>row();
			//2return $row=>id;
			return $q->row()->id;
		}
		else
		{
			return FALSE;
		}
		
	}

}
?>