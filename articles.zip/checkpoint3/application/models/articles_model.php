<?php
class Articles_model extends CI_Model{

	public function articles_list(){
//fetching data from db
		$user_id=$this->session->userdata ('user_id');
		$query=$this->db->select('title')
						->select('id')
							//->from('articles')
							->where('user_id',$user_id)
							->get('articles');
			
			return $query->result();


	}
	public function add_article($array)
	{
		return $this->db->insert('articles',$array);

		// $this->db->insert('ms_producttype',$params);
        // return $this->db->();
	}


	public function delete_article($array)
	{
		return $this->db->delete('articles',['id'=>$article_id]);
	}
}

?>