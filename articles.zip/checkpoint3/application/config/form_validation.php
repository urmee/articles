<?php

$config=[
'add_article_rules'=>[
					[
					'field'=>'title',
					'label'=>'Article Title',
					'rules'=>'required|alphdash'
					],
					[
					'field'=>'body',
					'label'=>'Article Body',
					'rules'=>'required',
					]
					],

'admin_login'=>[
					[
					'field'=>'username',
					'label'=>'UserName',
					'rules'=>'required|alph|trim'
					],
					[
					'field'=>'password',
					'label'=>'Password',
					'rules'=>'required'
					]
				]
	
	]

?>